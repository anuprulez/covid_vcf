download_readme.txt

The Terms of Use you agreed to when requesting access credentials to GISAID include the following:
1) You will not distribute data made available through GISAID (“Data in GISAID”) with others who have not agreed to the GISAID Terms of Use, and
2) You will not display the data in any form on a website without additional express written permission from GISAID, and
3) You will treat all data contained in these files consistent with other Data in GISAID and in accordance with the GISAID Terms of Use, and
4) You will provide proper attributions and acknowledgements consistent with the GISAID Terms of Use when using Data in GISAID in publications, manuscripts, and any other analyses.

By downloading these files, you are reaffirming your agreement to the GISAID Terms of Use and the Database Access Agreement.

